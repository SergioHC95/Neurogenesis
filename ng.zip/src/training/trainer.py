import os
from typing import Callable

import matplotlib.pyplot as plt
import torch
import torch.nn as nn
from IPython.display import clear_output
from loguru import logger
from torch.nn.utils import clip_grad_norm_
from torch.optim import Optimizer
from torch.utils.data import DataLoader
from tqdm import tqdm


class Trainer:
    """
    Trainer class for managing the training and validation of PyTorch models.

    Args:
        model (nn.Module): The model to train.
        optim (Optimizer): The optimizer for training.
        loss_f (callable): The loss function.
        train_loader (DataLoader): DataLoader for training data.
        val_loader (DataLoader, optional): DataLoader for validation data. Default: None.
        path (str, optional): Path to save/load checkpoints. Default: "./results/checkpoints/checkpoint.pt".
        resume_if_exists (bool, optional): Whether to resume from checkpoint if it exists. Default: True.
        gradient_clip (float, optional): Maximum norm for gradient clipping. Default: 1.0.
        device (str or torch.device, optional): Device to use ("cuda", "cpu", etc). Default: auto-detect.

    Attributes:
        model (nn.Module): The model being trained.
        optim (Optimizer): The optimizer.
        loss_f (callable): The loss function.
        train_loader (DataLoader): Training data loader.
        val_loader (DataLoader): Validation data loader.
        gradient_clip (float): Gradient clipping value.
        device (str): Device used for training.
        path (str): Checkpoint path.
        epoch (int): Current epoch.
        train_losses (list[float]): List of training losses per epoch.
        val_losses (list[float]): List of validation losses per epoch.
    """

    def __init__(
        self,
        model: nn.Module,
        optim: Optimizer,
        loss_f: Callable,
        train_loader: DataLoader,
        val_loader: DataLoader = None,
        path: str = "./results/checkpoints/checkpoint.pt",
        resume_if_exists: bool = True,
        gradient_clip: float = 1.0,
        device: str | torch.device = None,
    ):
        self.model = model
        self.optim = optim
        self.loss_f = loss_f
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.gradient_clip = gradient_clip

        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.model = model.to(self.device)

        self.path = path
        if resume_if_exists and os.path.exists(self.path):
            self.load_checkpoint()
        else:
            os.makedirs(os.path.dirname(self.path), exist_ok=True)
            self.epoch = 0
            self.train_losses = []
            self.val_losses = []

        logger.info("Initializing Trainer with device: {}", self.device)

    def preprocess_batch(
        self, batch: tuple[torch.Tensor, torch.Tensor]
    ) -> tuple[torch.Tensor, torch.Tensor]:
        inputs, targets = batch
        # Override if needed (e.g. flatten inputs, apply transforms)
        return inputs.to(self.device), targets.to(self.device)

    def train_epoch(self) -> float:
        self.model.train()
        total_loss = 0.0
        loader = tqdm(
            self.train_loader,
            desc=f"Epoch {self.epoch+1} [Train]",
            unit="batch",
            leave=False,
        )

        for batch in loader:
            inputs, targets = self.preprocess_batch(batch)
            self.optim.zero_grad()
            outputs = self.model(inputs)
            loss = self.loss_f(outputs, targets)
            loss.backward()
            clip_grad_norm_(self.model.parameters(), max_norm=self.gradient_clip)
            self.optim.step()
            total_loss += loss.item()
            loader.set_postfix(loss=loss.item())

        return total_loss / len(self.train_loader)

    @torch.no_grad()
    def val_epoch(self) -> float:
        """
        Run one validation epoch.

        Returns:
            float: Average validation loss for the epoch.
        """
        self.model.eval()
        total_loss = 0.0
        loader = tqdm(
            self.val_loader,
            desc=f"Epoch {self.epoch+1} [Val]",
            unit="batch",
            leave=False,
        )

        for batch in loader:
            inputs, targets = self.preprocess_batch(batch)
            outputs = self.model(inputs)
            loss = self.loss_f(outputs, targets)
            total_loss += loss.item()
            loader.set_postfix(loss=loss.item())

        return total_loss / len(self.val_loader)

    def train(
        self,
        epochs: int = 100,
        print_every: int = 10,
        validate_every: int = 10,
        plot: bool = False,
    ) -> tuple[list[float], list[float]]:
        """
        Train the model for a specified number of epochs.

        Args:
            epochs (int): Number of epochs to train.
            print_every (int): Print progress every N epochs.
            validate_every (int): Run validation every N epochs.
            plot (bool): Whether to plot the learning curve during training.

        Returns:
            Tuple[list[float], list[float]]: Lists of training and validation losses.
        """
        logger.info("Training started (epochs={})", epochs)
        end_epoch = self.epoch + epochs

        for epoch in range(self.epoch, end_epoch):
            train_loss = self.train_epoch()
            self.train_losses.append(train_loss)

            val_loss = None
            if self.val_loader and (
                epoch % validate_every == 0 or epoch == 0 or epoch == end_epoch - 1
            ):
                val_loss = self.val_epoch()
                self.val_losses.append(val_loss)

            self.epoch += 1
            self.save_checkpoint()

            logger.debug("Epoch {}: Train loss={:.4f}", epoch + 1, train_loss)

            if epoch == 0 or (epoch + 1) % print_every == 0:
                logger.info(
                    f"Epoch {epoch+1}/{end_epoch} | Train loss: {train_loss:.4f}"
                    + (f", Val loss: {val_loss:.4f}" if val_loss else "")
                )

            if plot and ((epoch + 1) % print_every == 0 or epoch == end_epoch - 1):
                self.plot_learning_curve()

        logger.success("Training completed")
        return self.train_losses, self.val_losses

    @torch.no_grad()
    def evaluate(self, loader: DataLoader) -> float:
        """
        Evaluate the model on a given data loader.

        Args:
            loader (DataLoader): DataLoader to evaluate on.

        Returns:
            float: Accuracy of the model on the provided data.
        """
        self.model.eval()
        correct = total = 0
        for batch in loader:
            inputs, targets = self.preprocess_batch(batch)
            y_preds = self.model(inputs).argmax(dim=1)
            correct += (y_preds == targets).sum().item()
            total += targets.size(0)
        acc = correct / total
        return acc

    def save_checkpoint(self) -> None:
        """
        Save the current model, optimizer, and training state to a checkpoint file.
        """
        checkpoint = {
            "model": self.model.state_dict(),
            "optimizer": self.optim.state_dict(),
            "epoch": self.epoch,
            "train_losses": self.train_losses,
            "val_losses": self.val_losses,
        }
        torch.save(checkpoint, self.path)

    def load_checkpoint(self) -> None:
        """
        Load model, optimizer, and training state from a checkpoint file.
        """
        logger.warning("Resuming from checkpoint: {}", self.path)
        checkpoint = torch.load(self.path)
        self.model.load_state_dict(checkpoint["model"])
        self.optim.load_state_dict(checkpoint["optimizer"])
        self.epoch = checkpoint["epoch"]
        self.train_losses = checkpoint["train_losses"]
        self.val_losses = checkpoint["val_losses"]
        logger.info(
            f"Resumed on {self.device} from epoch {self.epoch}: Train loss {self.train_losses[-1]:.4f}"
            + (f", Val loss {self.val_losses[-1]:.4f}" if self.val_losses else "")
        )

    def plot_learning_curve(
        self,
        save: bool = False,
        path: str = "./results/plots/learning_curve.png",
        show: bool = True,
    ) -> None:
        """
        Plot the learning curve of training and validation losses.

        Args:
            save (bool): If True, save the plot to the specified path. Otherwise, display it.
            path (str): Path to save the plot if save=True.
        """
        clear_output(wait=True)
        plt.figure(figsize=(8, 5))
        plt.plot(self.train_losses, label="Train Loss", color="blue")
        if self.val_losses:
            plt.plot(self.val_losses, label="Val Loss", color="orange")
        plt.xlabel("Epoch")
        plt.ylabel("Loss")
        plt.title("Learning Curve")
        plt.legend()
        plt.grid(True)
        plt.tight_layout()

        if save:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            plt.savefig(path)
            logger.info(f"Saved plot to {path}")
            plt.close()
        elif show:
            plt.show()
        else:
            plt.close()
